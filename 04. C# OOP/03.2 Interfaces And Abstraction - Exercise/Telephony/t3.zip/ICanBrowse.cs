﻿namespace Telephony
{
    public interface ICanBrowse
    {
        public void Browse(string site);
    }
}
