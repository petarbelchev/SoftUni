﻿namespace Telephony
{
    public interface ICanCall
    {
        public void Call(string number);
    }
}
